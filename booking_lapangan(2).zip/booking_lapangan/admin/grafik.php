<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT l.nama_lapangan, COUNT(b.id_booking) AS total 
    FROM lapangan l
    LEFT JOIN booking b ON b.id_lapangan = l.id_lapangan
    GROUP BY l.nama_lapangan
");

$labels = [];
$data = [];
while ($row = mysqli_fetch_assoc($query)) {
    $labels[] = $row['nama_lapangan'];
    $data[] = $row['total'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Grafik Penggunaan Lapangan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f0f8ff; padding: 30px; }
        h2 { text-align: center; color: #0077b6; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 10px; }
        canvas { margin-top: 30px; }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #ccc;
            color: black;
            text-decoration: none;
            border-radius: 6px;
        }
        .back-btn:hover { background: #bbb; }
    </style>
</head>
<body>
<div class="container">
    <h2>Grafik Penggunaan Lapangan</h2>
    <canvas id="lapanganChart"></canvas>
    <a class="back-btn" href="index.php">⬅ Kembali ke Dashboard</a>
</div>

<script>
    const ctx = document.getElementById('lapanganChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Jumlah Booking',
                data: <?= json_encode($data) ?>,
                backgroundColor: '#00b4d8'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
</script>
</body>
</html>
