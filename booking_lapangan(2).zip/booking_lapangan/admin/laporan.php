<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$laporan = mysqli_query($conn, "
    SELECT b.*, l.nama_lapangan, u.nama 
    FROM booking b 
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan 
    JOIN user u ON b.id_user = u.id_user 
    ORDER BY b.tanggal DESC
");

if (!$laporan) {
    die("Query Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Laporan Booking Lapangan</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 30px;
            background: #f4f9ff;
        }
        h2 {
            text-align: center;
            color: #0077b6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #caf0f8;
            color: #023e8a;
        }
        tr:nth-child(even) {
            background: #e0f7fa;
        }
        .buttons {
            margin-top: 20px;
            text-align: center;
        }
        button, a.button-link {
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
        }
        button.print {
            background: #00b4d8;
            color: white;
        }
        a.button-link.excel {
            background: #38b000;
            color: white;
        }
        a.button-link.grafik {
            background: #0096c7;
            color: white;
        }
        a.button-link.back {
            background: #bbb;
            color: black;
        }
        button.print:hover,
        a.button-link:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <h2>Laporan Data Booking Lapangan</h2>

    <div class="buttons">
        <button class="print" onclick="window.print()">🖨 Cetak</button>
        <a href="export_excel.php" class="button-link excel">📄 Export Excel</a>
        <a href="grafik.php" class="button-link grafik">📊 Lihat Grafik</a>
        <a href="index.php" class="button-link back">⬅ Kembali ke Dashboard</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pemesan</th>
                <th>Lapangan</th>
                <th>Tanggal</th>
                <th>Jam</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($laporan)) { ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['nama_lapangan']) ?></td>
                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                <td><?= htmlspecialchars($row['jam_mulai']) ?> - <?= htmlspecialchars($row['jam_selesai']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
