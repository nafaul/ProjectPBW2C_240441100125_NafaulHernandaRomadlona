<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

// Hapus booking
if (isset($_GET['hapus'])) {
    $id_hapus = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM booking WHERE id_booking='$id_hapus'");
    $pesan = "✔ Data booking berhasil dihapus.";
}

// Tambah booking
if (isset($_POST['tambah'])) {
    $id_user = $_POST['id_user'];
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    $status = $_POST['status'];

    mysqli_query($conn, "INSERT INTO booking (id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, status) 
        VALUES ('$id_user', '$id_lapangan', '$tanggal', '$jam_mulai', '$jam_selesai', '$status')");

    $pesan = "✔ Data booking berhasil ditambahkan.";
}

// Ambil data user dan lapangan
$users = mysqli_query($conn, "SELECT * FROM user WHERE role = 'user'");
$lapangans = mysqli_query($conn, "SELECT * FROM lapangan");

// Ambil data booking
$booking = mysqli_query($conn, "SELECT b.*, u.nama, l.nama_lapangan FROM booking b
    JOIN user u ON b.id_user = u.id_user
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    ORDER BY b.tanggal DESC");
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f9ff;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #0077b6;
            text-align: center;
            margin-bottom: 25px;
        }
        .pesan {
            text-align: center;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 6px;
            background-color: #e0f7e9;
            color: #027a48;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #cce5ff;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #caf0f8;
            color: #023e8a;
        }
        tr:nth-child(even) {
            background-color: #f1faff;
        }
        .status {
            padding: 6px 10px;
            border-radius: 6px;
            font-weight: bold;
            display: inline-block;
        }
        .waiting { background: #fff3cd; color: #856404; }
        .confirmed { background: #d4edda; color: #155724; }
        .rejected { background: #f8d7da; color: #721c24; }
        select {
            padding: 5px;
            font-weight: bold;
            border-radius: 5px;
        }
        a.dashboard {
            display: inline-block;
            margin-top: 15px;
            background-color: #0096c7;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
        }
        @media (max-width: 768px) {
            table, th, td {
                font-size: 13px;
            }
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Data Booking Masuk</h2>
    <h3>Tambah Booking Baru</h3>
<form method="post" style="margin-bottom: 30px;">
    <label>User:</label>
    <select name="id_user" required>
        <option value="">--Pilih User--</option>
        <?php while ($u = mysqli_fetch_assoc($users)) { ?>
            <option value="<?= $u['id_user'] ?>"><?= $u['nama'] ?></option>
        <?php } ?>
    </select>
    <label>Lapangan:</label>
    <select name="id_lapangan" required>
        <option value="">--Pilih Lapangan--</option>
        <?php while ($l = mysqli_fetch_assoc($lapangans)) { ?>
            <option value="<?= $l['id_lapangan'] ?>"><?= $l['nama_lapangan'] ?></option>
        <?php } ?>
    </select>
    <label>Tanggal:</label>
    <input type="date" name="tanggal" required>
    <label>Jam Mulai:</label>
    <input type="time" name="jam_mulai" required>
    <label>Jam Selesai:</label>
    <input type="time" name="jam_selesai" required>
    <label>Status:</label>
    <select name="status" required>
        <option value="Menunggu Konfirmasi">Menunggu Konfirmasi</option>
        <option value="Dikonfirmasi">Dikonfirmasi</option>
        <option value="Ditolak">Ditolak</option>
    </select>
    <button type="submit" name="tambah">Tambah Booking</button>
</form>


    <?php if ($pesan): ?>
        <div class="pesan"><?= $pesan ?></div>
    <?php endif; ?>

    <table>
        <tr>
            <th>Nama User</th>
            <th>Lapangan</th>
            <th>Tanggal</th>
            <th>Jam</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php while ($b = mysqli_fetch_assoc($booking)) { ?>
        <tr>
            <td><?= htmlspecialchars($b['nama']) ?></td>
            <td><?= htmlspecialchars($b['nama_lapangan']) ?></td>
            <td><?= $b['tanggal'] ?></td>
            <td><?= $b['jam_mulai'] ?> - <?= $b['jam_selesai'] ?></td>
            <td>
                <span class="status 
                    <?= $b['status'] == 'Menunggu Konfirmasi' ? 'waiting' : 
                        ($b['status'] == 'Dikonfirmasi' ? 'confirmed' : 'rejected') ?>">
                    <?= $b['status'] ?>
                </span>
            </td>
            <td>
                <form method="post">
                    <input type="hidden" name="id_booking" value="<?= $b['id_booking'] ?>">
                    <select name="ubah_status" onchange="this.form.submit()">
                        <option value="Menunggu Konfirmasi" <?= $b['status'] == 'Menunggu Konfirmasi' ? 'selected' : '' ?>>Menunggu</option>
                        <option value="Dikonfirmasi" <?= $b['status'] == 'Dikonfirmasi' ? 'selected' : '' ?>>Dikonfirmasi</option>
                        <option value="Ditolak" <?= $b['status'] == 'Ditolak' ? 'selected' : '' ?>>Ditolak</option>
                    </select>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>

    <a href="index.php" class="dashboard">⬅ Kembali ke Dashboard</a>
    <a href="cetak_bukti.php?id=<?= $row['id_booking'] ?>" target="_blank">🧾 Bukti</a>

</div>
</body>
</html>
