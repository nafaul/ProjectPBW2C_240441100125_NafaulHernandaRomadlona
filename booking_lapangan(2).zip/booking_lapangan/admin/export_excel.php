<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Set header untuk Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_booking.xls");

// Ambil data booking
$query = mysqli_query($conn, "SELECT b.*, u.nama, l.nama_lapangan, l.lokasi 
    FROM booking b 
    JOIN user u ON b.id_user = u.id_user 
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan 
    ORDER BY b.tanggal DESC");

echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Nama Pengguna</th>
        <th>Lapangan</th>
        <th>Lokasi</th>
        <th>Tanggal</th>
        <th>Jam Mulai</th>
        <th>Jam Selesai</th>
        <th>Status</th>
    </tr>";

$no = 1;
while ($row = mysqli_fetch_assoc($query)) {
    echo "<tr>
        <td>{$no}</td>
        <td>" . htmlspecialchars($row['nama']) . "</td>
        <td>" . htmlspecialchars($row['nama_lapangan']) . "</td>
        <td>" . htmlspecialchars($row['lokasi']) . "</td>
        <td>{$row['tanggal']}</td>
        <td>{$row['jam_mulai']}</td>
        <td>{$row['jam_selesai']}</td>
        <td>{$row['status']}</td>
    </tr>";
    $no++;
}
echo "</table>";
?>
