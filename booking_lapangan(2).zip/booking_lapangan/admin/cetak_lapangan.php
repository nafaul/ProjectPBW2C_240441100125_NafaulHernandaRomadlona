<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$lapangan = mysqli_query($conn, "SELECT * FROM lapangan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Data Lapangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f0f0f0;
        }
        .btn-cetak {
            display: inline-block;
            margin-bottom: 20px;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
        }

        @media print {
            .btn-cetak {
                display: none;
            }
        }
    </style>
</head>
<body>

<a href="#" class="btn-cetak" onclick="window.print()">🖨 Cetak / Simpan PDF</a>

<h2>Data Lapangan</h2>
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Lapangan</th>
            <th>Lokasi</th>
            <th>Harga per Jam</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($lapangan)) {
            echo "<tr>
                    <td>$no</td>
                    <td>".htmlspecialchars($row['nama_lapangan'])."</td>
                    <td>".htmlspecialchars($row['lokasi'])."</td>
                    <td>Rp".number_format($row['harga_per_jam'])."</td>
                  </tr>";
            $no++;
        }
        ?>
    </tbody>
</table>

</body>
</html>
