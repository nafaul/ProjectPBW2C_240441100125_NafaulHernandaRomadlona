<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

// Konfirmasi booking
if (isset($_GET['konfirmasi'])) {
    $id = $_GET['konfirmasi'];
    mysqli_query($conn, "UPDATE booking SET status='Dikonfirmasi' WHERE id_booking='$id'");
    $pesan = "✔ Booking berhasil dikonfirmasi.";
}

// Tolak booking
if (isset($_GET['tolak'])) {
    $id = $_GET['tolak'];
    mysqli_query($conn, "UPDATE booking SET status='Ditolak' WHERE id_booking='$id'");
    $pesan = "✔ Booking telah ditolak.";
}

// Hapus booking
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM booking WHERE id_booking='$id'");
    $pesan = "✔ Data booking berhasil dihapus.";
}

// Tambah booking
if (isset($_POST['tambah'])) {
    $id_user = $_POST['id_user'];
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    $status = $_POST['status'];

    mysqli_query($conn, "INSERT INTO booking (id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, status)
        VALUES ('$id_user', '$id_lapangan', '$tanggal', '$jam_mulai', '$jam_selesai', '$status')");
    $pesan = "✔ Booking baru berhasil ditambahkan.";
}

// Ambil data user dan lapangan untuk form tambah
$users = mysqli_query($conn, "SELECT * FROM user WHERE role='user'");
$lapangans = mysqli_query($conn, "SELECT * FROM lapangan");

// Ambil data booking
$booking = mysqli_query($conn, "SELECT b.*, u.nama, l.nama_lapangan FROM booking b
    JOIN user u ON b.id_user = u.id_user
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    ORDER BY b.tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Booking</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f9ff;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1100px;
            margin: auto;
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #0077b6;
            text-align: center;
        }
        .pesan {
            background: #d4edda;
            padding: 10px;
            border-radius: 6px;
            color: #155724;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 30px;
        }
        form label {
            display: inline-block;
            width: 120px;
            margin-top: 10px;
        }
        form input, form select {
            padding: 6px;
            margin-top: 10px;
            border-radius: 4px;
            width: 200px;
        }
        form button {
            background-color: #0077b6;
            color: white;
            padding: 8px 16px;
            border: none;
            margin-top: 15px;
            border-radius: 6px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #cce5ff;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #caf0f8;
            color: #023e8a;
        }
        tr:nth-child(even) {
            background-color: #f1faff;
        }
        a.button {
            text-decoration: none;
            padding: 6px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 13px;
        }
        a.konfirmasi { background-color: #38b000; color: white; }
        a.tolak { background-color: #d00000; color: white; }
        a.hapus { background-color: #6c757d; color: white; }
        a.dashboard {
            display: inline-block;
            background-color: #0096c7;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
        }
        @media (max-width: 768px) {
            table, th, td {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Data Booking</h2>

    <?php if ($pesan): ?>
        <div class="pesan"><?= $pesan ?></div>
    <?php endif; ?>

    <h3>Tambah Booking Baru</h3>
    <form method="post">
        <label for="id_user">User</label>
        <select name="id_user" required>
            <option value="">-- Pilih User --</option>
            <?php while ($u = mysqli_fetch_assoc($users)) { ?>
                <option value="<?= $u['id_user'] ?>"><?= $u['nama'] ?></option>
            <?php } ?>
        </select><br>
        <label for="id_lapangan">Lapangan</label>
        <select name="id_lapangan" required>
            <option value="">-- Pilih Lapangan --</option>
            <?php while ($l = mysqli_fetch_assoc($lapangans)) { ?>
                <option value="<?= $l['id_lapangan'] ?>"><?= $l['nama_lapangan'] ?></option>
            <?php } ?>
        </select><br>
        <label for="tanggal">Tanggal</label>
        <input type="date" name="tanggal" required><br>
        <label for="jam_mulai">Jam Mulai</label>
        <input type="time" name="jam_mulai" required><br>
        <label for="jam_selesai">Jam Selesai</label>
        <input type="time" name="jam_selesai" required><br>
        <label for="status">Status</label>
        <select name="status" required>
            <option value="Menunggu Konfirmasi">Menunggu Konfirmasi</option>
            <option value="Dikonfirmasi">Dikonfirmasi</option>
            <option value="Ditolak">Ditolak</option>
        </select><br>
        <button type="submit" name="tambah">Tambah Booking</button>
    </form>

    <table>
        <tr>
            <th>Nama User</th>
            <th>Lapangan</th>
            <th>Tanggal</th>
            <th>Jam</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php while ($b = mysqli_fetch_assoc($booking)) { ?>
        <tr>
            <td><?= htmlspecialchars($b['nama']) ?></td>
            <td><?= htmlspecialchars($b['nama_lapangan']) ?></td>
            <td><?= $b['tanggal'] ?></td>
            <td><?= $b['jam_mulai'] ?> - <?= $b['jam_selesai'] ?></td>
            <td><?= $b['status'] ?></td>
            <td>
                <?php if ($b['status'] == 'Menunggu Konfirmasi') { ?>
                    <a href="?konfirmasi=<?= $b['id_booking'] ?>" class="button konfirmasi">✔ Konfirmasi</a>
                    <a href="?tolak=<?= $b['id_booking'] ?>" class="button tolak" onclick="return confirm('Tolak booking ini?')">✖ Tolak</a>
                <?php } ?>
                <a href="?hapus=<?= $b['id_booking'] ?>" class="button hapus" onclick="return confirm('Yakin ingin hapus booking ini?')">🗑 Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>
    <a href="index.php" class="dashboard">⬅ Kembali ke Dashboard</a>
</div>
</body>
</html>
