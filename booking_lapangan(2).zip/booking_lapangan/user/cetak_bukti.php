<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "ID booking tidak ditemukan.";
    exit;
}

$id = $_GET['id'];
$user_id = $_SESSION['user']['id_user'];

$query = mysqli_query($conn, "SELECT b.*, l.nama_lapangan, l.lokasi, u.nama
    FROM booking b
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    JOIN user u ON b.id_user = u.id_user
    WHERE b.id_booking = '$id' AND b.id_user = '$user_id'");

if (mysqli_num_rows($query) == 0) {
    echo "Data booking tidak ditemukan.";
    exit;
}

$data = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Bukti Booking</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 40px;
            background: #f8f9fa;
        }
        .bukti {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #0077b6;
        }
        table {
            width: 100%;
            margin-top: 20px;
        }
        td {
            padding: 10px;
        }
        .label {
            width: 40%;
            font-weight: bold;
            color: #333;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #555;
        }
        .actions {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 25px;
        }
        .actions button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }
        .print-btn {
            background: #00b4d8;
            color: white;
        }
        .print-btn:hover {
            background: #0077b6;
        }
        .back-btn {
            background: #e0e0e0;
            color: #333;
        }
        .back-btn:hover {
            background: #cfcfcf;
        }
        @media print {
            .actions {
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="bukti">
    <h2>Bukti Booking Lapangan</h2>
    <table>
        <tr><td class="label">Nama Pemesan</td><td><?= htmlspecialchars($data['nama']) ?></td></tr>
        <tr><td class="label">Lapangan</td><td><?= htmlspecialchars($data['nama_lapangan']) ?> - <?= htmlspecialchars($data['lokasi']) ?></td></tr>
        <tr><td class="label">Tanggal</td><td><?= $data['tanggal'] ?></td></tr>
        <tr><td class="label">Jam</td><td><?= $data['jam_mulai'] ?> - <?= $data['jam_selesai'] ?></td></tr>
        <tr><td class="label">Status</td><td><?= $data['status'] ?></td></tr>
    </table>

    <div class="actions">
        <button class="print-btn" onclick="window.print()">🖨 Cetak Bukti</button>
        <button class="back-btn" onclick="window.history.back()">⬅ Kembali</button>
    </div>

    <div class="footer">
        Terima kasih telah melakukan booking. Silakan tunjukkan bukti ini saat check-in.
    </div>
</div>
</body>
</html>
