<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user']['id_user'];
$booking = mysqli_query($conn, "SELECT b.*, l.nama_lapangan, l.lokasi FROM booking b
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    WHERE b.id_user = '$user_id' ORDER BY b.tanggal DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Booking</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f8ff;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background: #e0f7fa;
            color: #333;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        a.button {
            display: inline-block;
            padding: 6px 12px;
            background: #4db8ff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
        }

        a.button:hover {
            background: #3399ff;
        }

        .back-link {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #555;
            background: #eee;
            padding: 10px 14px;
            border-radius: 8px;
        }

        .back-link:hover {
            background: #ddd;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Data Booking Anda</h2>

    <table>
        <tr>
            <th>Lapangan</th>
            <th>Tanggal</th>
            <th>Jam</th>
            <th>Status</th>
            <th>Cetak</th>
        </tr>
        <?php while ($b = mysqli_fetch_assoc($booking)) { ?>
        <tr>
            <td><?= $b['nama_lapangan'] ?> - <?= $b['lokasi'] ?></td>
            <td><?= $b['tanggal'] ?></td>
            <td><?= $b['jam_mulai'] ?> - <?= $b['jam_selesai'] ?></td>
            <td><?= $b['status'] ?></td>
            <td>
             <a class="button" href="cetak_bukti.php?id=<?= $b['id_booking'] ?>">🖨 Cetak</a>

            </td>
        </tr>
        <?php } ?>
    </table>

    <a class="back-link" href="index.php">⬅ Kembali ke Dashboard</a>
</div>
</body>
</html>
