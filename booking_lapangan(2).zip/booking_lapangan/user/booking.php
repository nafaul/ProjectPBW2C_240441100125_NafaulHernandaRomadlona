<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user']['id_user'];
$pesan = "";
$lapangan = mysqli_query($conn, "SELECT * FROM lapangan");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

   date_default_timezone_set('Asia/Jakarta');
$tanggal_hari_ini = date("Y-m-d");
$jam_sekarang = date("H:i");

if ($tanggal < $tanggal_hari_ini) {
    $pesan = "⛔ Tidak dapat booking tanggal yang sudah lewat.";
} elseif ($tanggal == $tanggal_hari_ini && $jam_mulai <= $jam_sekarang) {
    $pesan = "⛔ Jam mulai tidak boleh di masa lalu.";
} else {

        $cek = mysqli_query($conn, "SELECT * FROM booking WHERE id_lapangan='$id_lapangan' AND tanggal='$tanggal' AND (
            (jam_mulai < '$jam_selesai' AND jam_selesai > '$jam_mulai')
        )");

        if (mysqli_num_rows($cek) > 0) {
            $pesan = "⚠️ Jam tersebut sudah dibooking. Silakan pilih jam lain.";
        } else {
            mysqli_query($conn, "INSERT INTO booking (id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, status)
                VALUES ('$user_id', '$id_lapangan', '$tanggal', '$jam_mulai', '$jam_selesai', 'Menunggu Konfirmasi')");
            $pesan = "✅ Booking berhasil! Silakan tunggu konfirmasi admin.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Lapangan</title>
    <style>
        body {
            background: #f1faff;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            background: #ffffff;
            max-width: 500px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.08);
        }
        h2 {
            text-align: center;
            color: #0077b6;
            margin-bottom: 25px;
        }
        form label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        form input, form select {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-bottom: 12px;
            font-size: 14px;
        }
        button {
            background: #00b4d8;
            color: white;
            padding: 10px;
            border: none;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }
        button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        button:hover:enabled {
            background: #0096c7;
        }
        .error {
            background: #fff3cd;
            color: #856404;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
        }
        .validasi-jam {
            font-size: 13px;
            color: red;
            margin-top: -10px;
            margin-bottom: 10px;
        }
        a {
            text-decoration: none;
            color: #0077b6;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Form Booking Lapangan</h2>
   <?php if ($pesan): ?>
    <div class="error"><?= $pesan ?></div>
    <?php if (strpos($pesan, '✅') !== false): ?>
        <div style="text-align:center; margin-top: 15px;">
            <a href="databooking.php" style="display:inline-block; background:#00b4d8; color:#fff; padding:10px 20px; border-radius:6px; text-decoration:none; margin-top:10px;">🔁 Lihat Data Booking</a>
        </div>
    <?php endif; ?>
<?php endif; ?>


    <form method="POST" id="formBooking">
        <label for="id_lapangan">Pilih Lapangan</label>
        <select name="id_lapangan" id="id_lapangan" required>
            <option value="">-- Pilih --</option>
            <?php while ($l = mysqli_fetch_assoc($lapangan)) { ?>
                <option value="<?= $l['id_lapangan'] ?>">
                    <?= $l['nama_lapangan'] ?> - <?= $l['lokasi'] ?>
                </option>
            <?php } ?>
        </select>

        <label for="tanggal">Tanggal</label>
        <input type="date" name="tanggal" id="tanggal" required min="<?= date('Y-m-d') ?>">

        <label for="jam_mulai">Jam Mulai</label>
        <input type="time" name="jam_mulai" id="jam_mulai" required>

        <label for="jam_selesai">Jam Selesai</label>
        <input type="time" name="jam_selesai" id="jam_selesai" required>

        <p class="validasi-jam" id="peringatan-jam"></p>

        <button type="submit" id="tombolBooking">Booking</button>
    </form>

    <p style="text-align:center; margin-top: 15px;">
        <a href="index.php">⬅ Kembali ke Dashboard</a>
    </p>
</div>

<script>
    const jamMulai = document.getElementById('jam_mulai');
    const jamSelesai = document.getElementById('jam_selesai');
    const tombolBooking = document.getElementById('tombolBooking');
    const peringatanJam = document.getElementById('peringatan-jam');

    function cekValidasiJam() {
        if (jamMulai.value && jamSelesai.value) {
            if (jamSelesai.value <= jamMulai.value) {
                peringatanJam.textContent = "Jam selesai harus lebih besar dari jam mulai!";
                tombolBooking.disabled = true;
            } else {
                peringatanJam.textContent = "";
                tombolBooking.disabled = false;
            }
        }
    }

    jamMulai.addEventListener('input', cekValidasiJam);
    jamSelesai.addEventListener('input', cekValidasiJam);
</script>
</body>
</html>
