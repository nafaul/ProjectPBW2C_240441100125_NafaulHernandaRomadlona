<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard User</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #FEE9AE, #AEE6FE);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
            width: 100%;
        }

        h2 {
            margin-bottom: 30px;
            color: #333;
        }

        a {
            display: block;
            text-decoration: none;
            margin: 15px 0;
            padding: 12px;
            background: #4db8ff;
            color: white;
            border-radius: 8px;
            transition: background 0.3s;
            font-size: 16px;
        }

        a:hover {
            background: #3399ff;
        }

        a.logout {
            background: #ff6b6b;
        }

        a.logout:hover {
            background: #ff4c4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Selamat datang, <?= htmlspecialchars($user['nama']) ?> 👋</h2>

        <a href="booking.php">+ Booking Lapangan</a>
        <a href="databooking.php">📋 Lihat Data Booking</a>
        <a class="logout" href="../logout.php">🚪 Logout</a>
    </div>
</body>
</html>
